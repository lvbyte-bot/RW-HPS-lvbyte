<?xml version="1.0" encoding="UTF-8"?>
<tileset name="decoration" tilewidth="20" tileheight="20">
 <image source="bitmaps/decoration.png" width="140" height="100"/>
 
</tileset>
