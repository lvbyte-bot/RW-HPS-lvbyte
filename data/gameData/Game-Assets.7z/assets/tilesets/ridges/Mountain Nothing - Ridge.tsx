<?xml version="1.0" encoding="UTF-8"?>
<tileset name="Mountain Nothing - Ridge" tilewidth="20" tileheight="20" tilecount="15" columns="3">
 <image source="bitmaps/mountain2nothing_ridge.png" trans="008a76" width="60" height="100"/>
 <tile id="0">
  <properties>
   <property name="large-cliff" value=""/>
  </properties>
 </tile>
 <tile id="1">
  <properties>
   <property name="large-cliff" value=""/>
  </properties>
 </tile>
 <tile id="2">
  <properties>
   <property name="large-cliff" value=""/>
  </properties>
 </tile>
 <tile id="3">
  <properties>
   <property name="large-cliff" value=""/>
  </properties>
 </tile>
 <tile id="5">
  <properties>
   <property name="large-cliff" value=""/>
  </properties>
 </tile>
 <tile id="6">
  <properties>
   <property name="large-cliff" value=""/>
  </properties>
 </tile>
 <tile id="7">
  <properties>
   <property name="large-cliff" value=""/>
  </properties>
 </tile>
 <tile id="8">
  <properties>
   <property name="large-cliff" value=""/>
  </properties>
 </tile>
 <tile id="10">
  <properties>
   <property name="large-cliff" value=""/>
  </properties>
 </tile>
 <tile id="11">
  <properties>
   <property name="large-cliff" value=""/>
  </properties>
 </tile>
 <tile id="13">
  <properties>
   <property name="large-cliff" value=""/>
  </properties>
 </tile>
 <tile id="14">
  <properties>
   <property name="large-cliff" value=""/>
  </properties>
 </tile>
</tileset>
