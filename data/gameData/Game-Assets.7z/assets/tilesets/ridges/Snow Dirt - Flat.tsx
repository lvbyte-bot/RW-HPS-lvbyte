<?xml version="1.0" encoding="UTF-8"?>
<tileset name="Snow Dirt - Flat" tilewidth="20" tileheight="20">
 <image source="bitmaps/snow2dirt_flat.png" trans="008a76"/>
</tileset>
